Dark Dungeon
============

To play Dark Dungeon, please run the "setup.exe" file. This will
install everything needed to play Dark Dungeon onto your
computer. From there, simply run the newly installed "Dark Dungeon"
program.